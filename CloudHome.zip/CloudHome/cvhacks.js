$(document).ready(function(){
 var commcellID="fffff";
var regCode="";
var seNum = "";
var ipAddr = "";
var emailAddress = "";
var PassBase64 = "";
var firstName = "";
var lastName = "";
var isRegistered = 0;
var isExistingUser = 0;
 $('.showOnClick').hide();
 
$('.seeMore').click(function(){
	$('.showOnClick').show();
	$('.seeMore').hide();
	});

	

});